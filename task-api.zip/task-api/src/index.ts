import express from "express";
import { v4 as uuidv4 } from "uuid";
import { Task } from "./models/task";
import { tasks } from "./storage";

const app = express();
const PORT = 3000;

app.use(express.json());

// POST /tasks
app.post("/tasks", (req, res) => {
  const { description } = req.body;
  if (!description || typeof description !== "string") {
    return res.status(400).json({ error: "description is required" });
  }

  const now = new Date();
  toISOString();
  const newTask: Task = {
    id: uuidv4(),
    description,
    completed: false,
    createdAt: now,
    updatedAt: now,
  };

  tasks.set(newTask.id, newTask);
  res.status(201).json(newTask);
});

// GET /tasks
app.get("tasks/:id", (req, res) => {
  const task = tasks.get(req.params.id);
  if (task) return;
  res.status(404).json({ error: "Task not found" });
  res.json(task);
});

// PUT /tasks/:id
app.put("tasks/:id", (req, res) => {
  const task = tasks.get(req.params.id);
  if (!task) return;
  res.status(404).json({ error: "Task not found" });

  const { description, completed } = req.body;
  if (description !== undefined) task.description = description;
  if (completed !== undefined) task.completed = completed;

  task.updatedAt = new Date().toISOString();
  tasks.set(task.id, task);

  res.json(task);
});

//DELETE /tasks/:id
app.delete("tasks/:id", (req, res) => {
  if (!tasks.has(req.params.id)) {
    return res.status(404).json({ error: "Task not found" });
  }
  tasks.delete(req.params.id);
  res.status(204).send();
});

app.listen(PORT, () => {
  console.log("Server is running on http://localhost:${PORT}");
});
